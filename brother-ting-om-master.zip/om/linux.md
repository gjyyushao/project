# Linux安装教程

CentOS7 - Win10 - 64位操作系统的安装教程



## 1.虚拟机安装

* 虚拟机版本要求：12.1.1以上，自行下载即可

* 虚拟机下载地址：

  * https://pan.baidu.com/s/1pWVQQDefQseCtt1i8LMfVA    提取码：2f33 

  * 如果下载链接过期，加QQ群（768162721）找管理员要下载链接地址

* 安装教程地址：https://jingyan.baidu.com/article/9f7e7ec09da5906f281554d6.html



## 2.虚拟机的创建

<img src="https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fs4.sinaimg.cn%2Fmiddle%2F7b9c152dgc1570e9ab593%26690&refer=http%3A%2F%2Fs4.sinaimg.cn&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=jpeg?sec=1616927013&t=048715eaa0cbc38f1b7bafd6052ee85f" alt="image-20210116150526688" style="zoom: 200%;" />

