package com.zero2oneit.mall.common.bean.member;

import lombok.Data;

/**
 * Description:
 *
 * @author leon
 * @date 2021/2/24 19:54
 */
@Data
public class LeaderVo {
    private String memberId;
    private Integer gradeId;
    private Integer starId;
    private Integer starOpen;

}
