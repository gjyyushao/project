package com.zero2oneit.mall.common.query.member;

import com.zero2oneit.mall.common.utils.query.QueryObject;
import lombok.Data;

/**
 * Description:
 *
 * @author Atzel
 * @date 2021/2/19 15:32
 */
@Data
public class MemberStarLevelObject extends QueryObject {

    //星级名称
    private String starName;

}
